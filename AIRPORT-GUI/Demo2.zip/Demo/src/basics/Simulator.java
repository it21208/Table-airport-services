/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package basics;

import java.util.Calendar;
import java.util.Date;

/**
 * This class can twist time so that it fits specific simulation needs.
 * It can produce "simulated current time" for all listening objects
 * starting from an actual startDateTime
 */
public class Simulator {
    // --------------- ΓΝΩΡΙΣΜΑΤΑ ----------------------------------------
    private final Date startDateTime;
    private final long msecsStartDateTime;
    private final Calendar calendar; // 
    private int simsecToactualsecRatio; // 1:simsecToactualsecRatio
    
    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------
    public Date getStartDateTime() {
        return startDateTime;
    }

    public Calendar getCalendar() {
        return calendar;
    }

    public int getSimsecToactualsecRatio() {
        return simsecToactualsecRatio;
    }

    public void setSimsecToactualsecRatio(int simsecToactualsecRatio) throws Exception {
        if (simsecToactualsecRatio >= 1)
            this.simsecToactualsecRatio = simsecToactualsecRatio;
        else
            throw new Exception("Simulated to Actual seconds ratio can not be < 1");
    }

    // ------------ ΜΕΘΟΔΟΙ ΚΑΤΑΣΚΕΥΑΣΤΕΣ -------------------------------
    /* Κατασκευαστής 1 -------
     *  Δημιουργεί ένα simulator με συγκεριμένη ώρα έναρξης και
     *  αναλογία εικονικών προς πραγματικών δευτερολέπτων. Όταν δωθεί
     *  null στο startDateTime υποθέτει το NOW
     */
    public Simulator(Date startDateTime, int simsecToactualsecRatio) throws Exception {
        this.calendar = Calendar.getInstance(); // current date time
        if (startDateTime != null) { /* αν υπάρχει συγκεκριμένο date time
            αρχικοποιούμε τα πεδία startDateTime και calendar με αυτό */
            this.startDateTime = startDateTime;
            this.calendar.setTime(startDateTime);
        } else /* διαφορετικά
            αρχικοποιούμε και το πεδίο startDateTime με το current date time */
            this.startDateTime = calendar.getTime();
        // υπολογίζω το start date time σε msecs για λόγους απόδοσης
        this.msecsStartDateTime = this.calendar.getTimeInMillis();
        this.setSimsecToactualsecRatio(simsecToactualsecRatio);
    }
    
    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------
    
    /**
     * 
     * @return Επιστρέφει το εικονικό NOW του simulator
     */
    public Date getSimulatedTime() {
        Calendar calNow = Calendar.getInstance();
        // υπολογίζουμε σε msecs το NOW
        long msecsNow = calNow.getTimeInMillis();
        // υπολογίζουμε τα msecs από το start date time έως NOW 
        double secsDiff = (msecsNow - this.msecsStartDateTime)/1000;
        calNow.setTime(startDateTime);
        calNow.add(Calendar.SECOND, (int)(this.simsecToactualsecRatio * secsDiff));
        return calNow.getTime();
    }
}
