package basics;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class Flight implements Comparable<Flight> {

    // --------------- ΓΝΩΡΙΣΜΑΤΑ ----------------------------------------
    public static DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");;
    private final String code;
    private String departureTo;
    private String via;
    private FlightStatus status;
    private Date initialSchedDeparture; // προγρ. ώρα από αεροπ. εταιρεία
    private Date scheduledTimeSlot;  // προγρ. ώρα (slot) από αεροδρόμιο
    private Date expectedTimeSlot; /* τελευτ. προγρ. ώρα (slot) για
                                      πτήσεις που είχαν καθυστέρηση  */
    private final Airline airline; // αεροπορική εταιρεία όπου ανήκει

    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------
    public String getCode() {
        return code;
    }

    public String getFullCode() {
        return this.airline.getCode() + " " +
                this.code;
    }
    public String getDepartureTo() {
        return departureTo;
    }

    public void setDepartureTo(String departureTo) {
        this.departureTo = departureTo;
    }

    public String getVia() {
        return via;
    }

    public void setVia(String via) {
        this.via = via;
    }

    public FlightStatus getStatus() {
        return status;
    }

    /* Εδώ γίνεται ο συντονισμός για τυχόν ενέργειες
     * που πρέπει να γίνονται όταν συμβαίνουν μεταβάσεις
     * από μια κατάσταση σε άλλη. (state transion diagram)
     */
    public void setStatus(FlightStatus status) throws Exception {
        // εάν γίνεται μετάβαση σε κατάσταση Delayed
        if (status == FlightStatus.Delayed) {
            /* πρώτα ελέγχουμε εάν είναι επιτρεπτή (δηλ. μόνο εάν η
               υπάρχουσα κατάσταση είναι OnTime ή Delayed */
            if ((this.status == FlightStatus.OnTime) ||
                (this.status == FlightStatus.Delayed)) {
                // γίνεται η μετάβαση της κατάστασης και
                this.status = status;
                /* καλούμε το αεροδρόμιο (διαχειριστή) να δώσει
                   νέο time slot στην πτήση */
                this.airline.getAirport().getSlotForDelayedFlight(this);
            } else
                throw new Exception("Invalid status transition (" + 
                    this.status.toString() + " --> " + status.toString() );
        } else if (status == FlightStatus.Cancelled) {
            /* ελέγχουμε εάν είναι επιτρεπτή (δηλ. μόνο εάν η
               υπάρχουσα κατάσταση είναι Boarding ή Delayed */
            if ((this.status == FlightStatus.Boarding) ||
                (this.status == FlightStatus.Delayed)) {
                // γίνεται η μετάβαση της κατάστασης και
                this.status = status;
            } else
                throw new Exception("Invalid status transition (" + 
                    this.status.toString() + " --> " + status.toString() );
        } else { /* η μετάβαση στις άλλες καταστάσεις χωρίς
                    επιπλέον ενέργειες */
            this.status = status;
        }
    }
    
    public Date getInitialSchedDeparture() {
        return initialSchedDeparture;
    }

    public String getInitialSchedDepartureAsStr() {
        return Flight.formatter.format(this.initialSchedDeparture);
    }

    public void setInitialSchedDeparture(Date initialSchedDeparture) {
        this.initialSchedDeparture = initialSchedDeparture;
    }

    public void setInitialSchedDeparture(String initialSchedDeparture) throws ParseException {
        this.initialSchedDeparture = (Date)Flight.formatter.parse(initialSchedDeparture);    
    }
    
    public Date getExpectedTimeSlot() {
        return expectedTimeSlot;
    }

    public void setExpectedTimeSlot(Date expectedTimeSlot) {
        this.expectedTimeSlot = expectedTimeSlot;
    }

    public void setExpectedTimeSlot(String expectedTimeSlot) throws ParseException {
        this.expectedTimeSlot = (Date)Flight.formatter.parse(expectedTimeSlot);
    }
    
    public Date getScheduledTimeSlot() {
        return scheduledTimeSlot;
    }

    public void setScheduledTimeSlot(Date scheduledTimeSlot) {
        this.scheduledTimeSlot = scheduledTimeSlot;
    }

    public void setScheduledTimeSlot(String scheduledTimeSlot) throws ParseException {
        this.scheduledTimeSlot = (Date)Flight.formatter.parse(scheduledTimeSlot);
    }

    /* Επιστρέφει το πιό πρόσφατο time slot της πτήσης.
     * Χρησιμοποιείται για 
     *   α) την κατά σύμβαση ταξινόμηση πτήσεων
     *   β) για την ενεργοποίηση χρονικά εξαρτώμενων (ολικώς ή
     *      μερικώς) μεταβάσεων στις καταστάσεις πτήσεων: 
     *          OnTime      --> Boarding
     *          Delayed     --> Boarding 
     *          Boarding    --> Departed
     *   γ) για την εκτέλεση χρονικά εξαρτώμενων (ολικώς ή
     *      μερικώς) δράσεων:
     *          απελευθέρωση αεροδιαδρόμου από Departed πτήση
     *   δ) για το φιλτράρισμα των πρόσφατα Departed και
     *      Cancelled πτήσεων που πρέπει να εμφανίζει ο
     *      ΠΙΝΑΚΑΣ ΑΝΑΧΩΡΗΣΕΩΝ
     */
    public Date getValidTimeSlot() {
        return (this.expectedTimeSlot == null) ? 
                          this.scheduledTimeSlot :
                          this.expectedTimeSlot;
    }
    
    public Airline getAirline() {
        return airline;
    }
            
    // ------------ ΜΕΘΟΔΟΙ ΚΑΤΑΣΚΕΥΑΣΤΕΣ -------------------------------
    
    /* Κατασκευαστής 1 -------
     *  Δημιουργεί μια πτήση με ορίσματα τύπου String και μια
     *  αεροπορική εταιρεία. Αρχικοποιεί με λογικές τιμές τα πεδία
     *  status, scheduledTimeSlot, expectedTimeSlot και μετατρέπει
     *  το scheduledDeparture από String σε Date
     */
    public Flight(String code, String departureTo, String via, 
        String scheduledDeparture, Airline airline) 
            throws ParseException,NumberFormatException,Exception {
        // check if all four values are not null
        if (code.isEmpty() || departureTo.isEmpty() ||
            scheduledDeparture.isEmpty()) {
            throw new Exception("Flight constructor parameter(s)(Code, DepartureTo, Scheduled Date) empty");
        }
        // validate code (should be an int
        int ret = Integer.parseInt(code);
        this.code = code;
        this.departureTo = departureTo;
        this.via = via;
        setStatus(FlightStatus.OnTime);
        this.setInitialSchedDeparture(scheduledDeparture);
        this.expectedTimeSlot = null;
        this.scheduledTimeSlot = null;
        this.airline = airline;
    }
   
    // ------------------ ΛΕΙΤΟΥΡΓΙΕΣ ------------------------------------
    
    /**
     * Κάνει σύγκριση πτήσεων με βάση το υπολογιζόμενο πεδίο 
     *  the getValidTimeSlot().
     *  Μπορεί να χρησιμοποιηθεί για την ταξινόμηση πτήσεων
     */
    @Override
    public int compareTo(Flight o) {
        return this.getValidTimeSlot().compareTo(o.getValidTimeSlot());
    }
    
    /**
     * Επιστρέφει ένα String που περιγράφει τα στοιχεία της πτήσης
     * Χρησιμοποιείται από τις αντίστοιχες μεθόδους της Airline και
     * του Airport
     */
    @Override
    public String toString() {
        String columnsFormat = "%-25s%-15s%-25s%-20s%-20s%-20s%-15s";
        return String.format(columnsFormat, departureTo, code, via,
           ((expectedTimeSlot == null) ? "" : 
                   Flight.formatter.format(expectedTimeSlot)),
           ((scheduledTimeSlot == null) ? "" : 
                   Flight.formatter.format(scheduledTimeSlot)),
           ((initialSchedDeparture == null) ? "" : 
                   Flight.formatter.format(initialSchedDeparture)),
           status.toString());
    }        
}