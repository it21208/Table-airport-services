package basics;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;

public class Airport {
    
    // --------------- ΓΝΩΡΙΣΜΑΤΑ ----------------------------------------
    private Date startDateTime;   // έναρξη λειτουργίας αεροδρομίου
    private int operationDuration; // διάρκεια λειτουργίας (hours)
    private int timeSlotDuration; // διάρκεια σε (min) χρονοθυρίδας
    private int Runways;   // εγκατεστημένοι διάδρομοι 
    private int noOfFreeRunways;    // ελεύθεροι διάδρομοι
    private FlightsTable flightsTable;  // ΠΙΝΑΚΑΣ ΑΝΑΧΩΡΗΣΕΩΝ αεροδρομίου
    private ArrayList<Airline> airlinesList; // λίστα αεροπορικών εταιρειών
    private byte[] timeSlot; /* πίνακας με την κατάσταση κάθε time slot,
            * δηλαδή τον αριθμό των πτήσεων που έχουν ανατεθεί στην κάθε
            * χρονοθυρίδα */
    private Simulator simulator;

    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------
    public Date getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(Date startDateTime) {
        this.startDateTime = startDateTime;
    }

    public void setStartDateTime(int startTime) {
        /* με βάση το startTime π.χ 5 δημιουργείται ένα calendar που δείχνει
           στις 05:00πμ σήμερα και αρχικοποιείται η ώρα έναρξης αεροδρομίου
        */
        if ((startTime >= 0) && (startTime <24)) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, startTime);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            this.startDateTime = calendar.getTime();
        }
    }
    
    public int getOperationDuration() {
        return operationDuration;
    }

    public void setOperationDuration(int operationDuration) {
        this.operationDuration = operationDuration;
    }

    public Date getEndDateTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(this.startDateTime);
        calendar.add(Calendar.HOUR_OF_DAY, this.operationDuration);
        return calendar.getTime();        
    }

    public int getTimeSlotDuration() {
        return timeSlotDuration;
    }

    public void setTimeSlotDuration(int timeSlotDuration) {
        this.timeSlotDuration = timeSlotDuration;
    }

    public int getRunways() {
        return Runways;
    }

    public void setRunways(int Runways) {
        this.Runways = Runways;
    }

    public int getNoOfFreeRunways() {
        return noOfFreeRunways;
    }

    /* Γίνεται στοιχειώδης έλεγχος της τιμής έτσι ώστε:
     *   0 <= noOfFreeRunways <= Runways
     */
    public void setNoOfFreeRunways(int noOfFreeRunways) {
        if ((noOfFreeRunways >= 0) && (noOfFreeRunways <= Runways))
            this.noOfFreeRunways = noOfFreeRunways;
        else
            System.err.format("Λάθος: Airport.setNoOfAirways(<εκτός ορίων>%d)",
                    noOfFreeRunways);
    }

    public FlightsTable getFlightsTable() {
        return flightsTable;
    }

    public void setFlightsTable(FlightsTable flightsTable) {
        this.flightsTable = flightsTable;
    }
    public ArrayList<Airline> getAirlinesList() {
        return airlinesList;
    }

    public void setAirlinesList(ArrayList<Airline> airlinesList) {
        Iterator<Airline> ita;
        Airline a;
        this.airlinesList = airlinesList;
        ita = airlinesList.iterator();
        while (ita.hasNext()) {
            a = ita.next();
            a.setAirport(this);
        }
    }

    public ArrayList<Flight> getFlightsList(Comparator<Flight> FlightSortby) {
        Airline a;

        // Δημιουργία πλήρους (αταξινόμητης) λίστας πτήσεων
        ArrayList<Flight> arrFlights = new ArrayList<>();
        Iterator<Airline> ita = this.airlinesList.iterator();
        while (ita.hasNext()) {
            a = ita.next();
            arrFlights.addAll((Collection)a.getFlightsList());
        }        
        if (FlightSortby != null) {
            /* Η λίστα πτήσεων ταξινομείται με αύξουσα σειρά με βάση το
               αντικείμενο Ccomparator FlightSortby */
            Collections.sort(arrFlights, FlightSortby);
        } else {
            /* Η λίστα πτήσεων ταξινομείται με αύξουσα σειρά με βάση το
               κατά σύμβαση κριτήριο getValidTimeSlot() */
            Collections.sort(arrFlights);
        }
        return arrFlights;
    }

    public byte[] getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(byte[] timeSlot) {
        this.timeSlot = timeSlot;
    }

    public Simulator getSimulator() {
        return simulator;
    }

    public void setSimulator(Simulator simulator) {
        this.simulator = simulator;
    }    
    
    // ------------ ΜΕΘΟΔΟΙ ΚΑΤΑΣΚΕΥΑΣΤΕΣ -------------------------------
    
    /* Κατασκευαστής 1 -------
     *  Δημιουργεί ένα αεροδρόμιο με συγκεριμένη ώρα έναρξης, διάρκεια
     *  λειτουργίας (hours), διάρκεια χρονοθυρίδας (min), αριθμό
     *  διαδρόμων.
     *  Υπολογίζονται αυτόματα η ώρα λήξης λειτουργίας και το πλήθος
     *  των χρονοθυρίδων.
     */
    public Airport(int startTime, int operationDuration, 
            int timeSlotDuration, int maxAirways) throws Exception {
        this.setStartDateTime(startTime);
        this.operationDuration = operationDuration;
        // στην ώρα έναρξης αεροδρομίου προστίθεται η διάρκεια λειτουργίας
        // και αρχικοποιείται η ώρα λήξης αεροδρομίου
        this.timeSlotDuration = timeSlotDuration;
        this.Runways = maxAirways;
        this.noOfFreeRunways = maxAirways;
        this.flightsTable = null;
        this.airlinesList = new ArrayList<>();
        // από τη διάρκεια λειτουργίας υπολογίζεται το πλήθος των time slot
        int noOfTimeSlots = (int)((operationDuration*60) / timeSlotDuration);
        // δημιουργία του πίνακα χρονοθυρίδων
        this.timeSlot = new byte[noOfTimeSlots];
        this.simulator = new Simulator(null, 30);
    }
    
    // ------------------ ΛΕΙΤΟΥΡΓΙΕΣ ------------------------------------
    
    // Δημιουργεί και αρχικοποιεί τον ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ του αεροδρομίου
    public void InitializeFlightsTable(int displayLines, 
            int maxRecentlyDepartedFlightsToDisplay, 
            int maxRecentlyCancelledFlightsToDisplay, int refreshTime) {
        this.flightsTable = 
            new FlightsTable(displayLines, maxRecentlyDepartedFlightsToDisplay,
                  maxRecentlyCancelledFlightsToDisplay, refreshTime, this);
    }
    
    /*  Αναθέτει μια αεροπορική εταιρεία στο αεροδρόμιο.
     *  Προσομοιώνει δηκαδή την ενέργεια ότι κάθε πρωί οι αεροπορικές
     *  δίνουν τα δεδομένα πτήσεων τους στο αεροδρόμιο.
     */
    public void loadAirline(Airline airline) {
        this.airlinesList.add(airline);
        airline.setAirport(this);
    }
    
    /*  Όταν επιστρέφει true έχει αναθέσει στην πλήρη λίστα πτήσεων 
     *  όλων των αεροπορικών εταιριών το κατάλληλο time slot με βάση 
     *  την προγρ. ώρα από την αεροπορική εταιρεία και το πλήθος των 
     *  εγκατεστημένων διαδρόμων.
     */
    public boolean assignTimeSlotsToFlights() throws Exception {
        Flight f;
        ArrayList<Flight> arrFlights;      
        Iterator<Flight> itf;

        /* Δημιουργία πλήρους λίστας πτήσεων ταξινομημένης με αύξουσα 
           σειρά με βάση το scheduledDeparture (η προγρ. ώρα από την 
           αεροπορική εταιρεία) */
        arrFlights = this.getFlightsList(new FlightSortbyScheduledDeparture());
        /* εάν η προγρ. ώρα από την αεροπορική εταιρεία είναι εκτός
           ωραρίου λειτουργίας του αεροδρομίου,
           τότε κάνε έξοδο νωρίς και επέστρεψε false */
        if (!areFlightsListScheduledDeparturesValid(arrFlights)) {
            System.err.println("Λάθος: Airport.loadFlightsList() -"
                 + " Αποτυχία ελέγχου ορθότητας λίστας πτήσεων");
            return false;
        }
        // ανάθεση χρονοθυρίδας σε κάθε πτήση
        itf = arrFlights.iterator();
        while (itf.hasNext()) {
            f = itf.next();
            if (!this.getSlotForOnTimeFlight(f)) {
                System.err.println("Λάθος: Airport.loadFlightsList() -"
                + " Αποτυχία ανάθεσης χρονοθυρίδων σε όλη τη λίστα πτήσεων " + f.toString());
                return false;
            }
        }
        // επιτυχής τερματισμός
        return true;
    }
 
    /* Επιστρέφει true αν για κάθε πτήση της λίστας η προγρ. ώρα από 
     * την αεροπορική εταιρεία είναι εντός ωραρίου λειτουργίας του 
     * αεροδρομίου
     */
    private boolean areFlightsListScheduledDeparturesValid(
            ArrayList<Flight> flightsList) {
        boolean validScheduledDeparture;
        Flight f;
        Iterator<Flight> itf = flightsList.iterator();
        while (itf.hasNext()) {
            f = itf.next();
            validScheduledDeparture =
                this.startDateTime.before(f.getInitialSchedDeparture()) &&
                this.getEndDateTime().after(f.getInitialSchedDeparture());
            if (!validScheduledDeparture) {
                System.err.println("Λάθος: "
                + " Flight.initialSchedDeparture εκτός ωραρίου λειτουργίας");
                return false;
            }
        }
        return true;
    }
    
    // Ανάθεση χρονοθυρίδας σε μια πτήση OnTime για πρώτη φορά
    public boolean getSlotForOnTimeFlight(Flight f) throws ArrayIndexOutOfBoundsException, Exception {
        long msecScheduledDeparture, msecStartDateTime, 
             msecTimeSlotDuration, msecIndexTimeSlot, msecNow;
        int slotIndex;
        boolean slotIndexFound;
             
        /* εάν η πτήση δεν είναι OnTime ή έχει ανατεθεί σε κάποια
           χρονοθυρίδα τότε έξοδος */
        if ((f.getStatus() != FlightStatus.OnTime) ||
            (f.getScheduledTimeSlot() != null)) 
            return false;
        /* με το GUI είναι πλέον δυνατόν να τροποποιηθεί το Scheduled Departure
           με τιμή πριν την έναρξη του airport, κατάσταση που στην εργασία 1
           γίνονταν συνολικά από την areFlightsListScheduledDeparturesValid()
        */
        if (!(this.startDateTime.before(f.getInitialSchedDeparture()) &&
                this.getEndDateTime().after(f.getInitialSchedDeparture()))) {
            throw new Exception("Initial Scheduled Departure is out of the valid airport range!");
        }
        // μετατροπή σε msec του Airport.startDateTime
        msecStartDateTime = this.startDateTime.getTime();
        // μετατροπή σε msec του Airport.timeSlotDuration
        msecTimeSlotDuration = this.timeSlotDuration*60*1000;
        // μετατροπή σε msec του Flight.getScheduledDeparture
        msecScheduledDeparture = f.getInitialSchedDeparture().getTime();
        /* η πιο κατάλληλη χρονοθυρίδα είναι αυτή που είναι ίση ή
           μικρότερη του initialSchedDeparture */
        slotIndex = (int)((msecScheduledDeparture - msecStartDateTime) /
                    msecTimeSlotDuration);
        // αν αυτή η χρονοθυρίδα είναι διαθέσιμη
        if (this.timeSlot[slotIndex] < this.Runways) {
            // δέσμευσέ την
            this.timeSlot[slotIndex]++;
        } else { // αλλιώς βρες την επόμενη διαθέσιμη μετά από αυτήν
            slotIndex++;
            do {
                slotIndexFound = 
                        (this.timeSlot[slotIndex++] < this.Runways);
            } while ((!slotIndexFound) && (slotIndex < this.timeSlot.length));
            if (!slotIndexFound) {
                System.err.println("Λάθος: Airport.getSlotForOnTimeFlight() -"
             + " Δεν υπάρχει διαθέσιμη χρονοθυρίδα για την πτήση!");
                return false;
            } 
            this.timeSlot[--slotIndex]++;
        }
        // υπολογισμός ώρας έναρξης χρονοθυρίδας σε msec
        msecIndexTimeSlot = msecStartDateTime + 
                            slotIndex*msecTimeSlotDuration;
        // αποκοπή των sec και msec
        msecIndexTimeSlot = msecIndexTimeSlot - (msecIndexTimeSlot % 60000);
        // ανάθεση χρονοθυρίδας σε πτήση
        f.setScheduledTimeSlot(new Date(msecIndexTimeSlot));
        // επιτυχής τερματισμός        
        return true;
    }
    
    /* Ανάθεση χρονοθυρίδας σε μια πτήση Delayed
     * (μπορεί να γίνει πολλές φορές)
     */
    public boolean getSlotForDelayedFlight(Flight f) throws Exception {
        long msecStartDateTime, msecTimeSlotDuration, 
                msecIndexTimeSlot, msecTimeSlot;
        int slotIndex;
        boolean slotIndexFound;
             
        // εάν η πτήση δεν είναι Delayed τότε έξοδος
        if (f.getStatus() != FlightStatus.Delayed)
            return false;
        /* με το GUI είναι πλέον δυνατόν να τροποποιηθεί το Scheduled Departure
           με τιμή πριν την έναρξη του airport, κατάσταση που στην εργασία 1
           γίνονταν συνολικά από την areFlightsListScheduledDeparturesValid()
        */
        if (!(this.startDateTime.before(f.getInitialSchedDeparture()) &&
                this.getEndDateTime().after(f.getInitialSchedDeparture()))) {
            throw new Exception("Initial Scheduled Departure is out of the valid airport range!");
        }
  
        // μετατροπή σε msec του Airport.startDateTime
        msecStartDateTime = this.startDateTime.getTime();
        // μετατροπή σε msec του Airport.timeSlotDuration
        msecTimeSlotDuration = this.timeSlotDuration*60*1000;
        // μετατροπή σε msec του Flight.getValidTimeSlot
        msecTimeSlot = f.getValidTimeSlot().getTime();
        // βρες την επόμενη διαθέσιμη χρονοθυρίδα
        slotIndex = (int)((msecTimeSlot - msecStartDateTime) /
                           msecTimeSlotDuration) + 1;
        do {
            slotIndexFound = 
                    (this.timeSlot[slotIndex++] < this.Runways);

        } while ((!slotIndexFound) && (slotIndex < this.timeSlot.length));
        if (!slotIndexFound) {
            System.err.println("Λάθος: Airport.getSlotForDelayedFlight() -"
         + " Δεν υπάρχει διαθέσιμη χρονοθυρίδα για την πτήση!");
            return false;
        } 
        this.timeSlot[--slotIndex]++;
        // υπολογισμός ώρας έναρξης χρονοθυρίδας σε msec
        msecIndexTimeSlot = msecStartDateTime + 
                            slotIndex*msecTimeSlotDuration;
        // αποκοπή των sec και msec
        msecIndexTimeSlot = msecIndexTimeSlot - (msecIndexTimeSlot % 60000);
        // ανάθεση χρονοθυρίδας σε πτήση
        f.setExpectedTimeSlot(new Date(msecIndexTimeSlot));
        // επιτυχής τερματισμός         
        return true;
    }
    
    /* Επιστρέφει ένα String πολλαπλών γραμμών όπου περιγράφονται τα 
     * στοιχεία όλων των πτήσεων του αεροδρομίου.
     * Γενική χρήση πχ. έλεγχοι κατά τη διαδικασία ανάπτυξης
     */    
    @Override
    public String toString() {
        String s = "ΑΕΡΟΔΡΟΜΙΟ\n";
        Flight f;
        Iterator<Flight> it = this.getFlightsList(new FlightSortbyTimeSlot()).iterator();
        while (it.hasNext()) {
            f = it.next();
            s += (f.toString() + "\n");
        }
        return s;
    }    
}