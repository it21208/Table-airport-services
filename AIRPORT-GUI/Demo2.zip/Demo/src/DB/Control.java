/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DB;

import basics.Airline;
import basics.Airport;
import basics.Flight;
import basics.FlightsTable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

/**
 *
 * @author tioa
 */
public abstract class Control {
    // ------------------ ΛΕΙΤΟΥΡΓΙΕΣ ------------------------------------
    
    /* Δημιουργεί και επιστρέφει μια σύνδεση με τη ΒΔ 
     */
    public static Connection CreateDBConnection() {
        String url;
        Connection con = null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            url ="jdbc:oracle:thin:@//localhost:1521/xe";
            con = DriverManager.getConnection(url,"ALEX", "alex");
        } catch (ClassNotFoundException | SQLException e) { 
        } finally {
        }
        return con;
    }  
    
    /* Κλείνει μια ανοιχτή σύνδεση με τη ΒΔ 
     */
    public static void CloseDBConnection(Connection con) throws SQLException {
        if (con != null) con.close();
    }
    
    /* Δημιουργεί ένα Airport και ένα FlightTable από τη ΒΔ και
       αφού τα συνδέσει επιστρέφει το Airport. Η υπόθεση εργασίας είναι
       ότι υπάρχει το μέγιστο μια εγγραφή στον πίνακα AIRPORT.
       TODO: Πρέπει να προβλεφθεί η αντίδραση για την περίπτωση που
       δεν υπάρχει εγγραφή. Ίσως η καλύτερη λύση γι'α υτήν την περίπτωση
       να είναι η άμεση εισαγωγή μιας εγγραφής με συγκεκριμένες τιμές.
     */
    public static Airport ReadAirportFlightsTableFromDB(Connection con) throws SQLException, Exception {
        Statement stmt = null;
        String sqlselect;
        ResultSet rs = null;
        Airport a = null;
        FlightsTable ft = null;
        try {
            stmt = con.createStatement();
            sqlselect =         "SELECT STARTTIME,\n" +
                                    "  OPERATIONDURATION,\n" +
                                    "  TIMESLOTDURATION,\n" +
                                    "  RUNWAYS,\n" +
                                    "  FT_DISPLAYLINES,\n" +
                                    "  FT_RECENTLYDEPARTEDFLIGHTS,\n" +
                                    "  FT_RECENTLYCANCELLEDFLIGHTS,\n" +
                                    "  FT_REFRESHPERIOD\n" +
                                "FROM ALEX.AIRPORT";
            rs = stmt.executeQuery(sqlselect);
            rs.next();
            // create Airport and FlightsTable
            a = new Airport(rs.getInt(1), rs.getInt(2), 
                                    rs.getInt(3), rs.getInt(4));
            ft = new FlightsTable(rs.getInt(5), rs.getInt(6),
                                               rs.getInt(7), rs.getInt(8), a);
        } catch (SQLException e) {
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
        }
        return a;
    }

/* Αποθηκεύει στη ΒΔ ένα Airport και ένα FlightTable που είναι συνδεδεμένο
    με το Airport. Εάν δεν υπάρχει εγγραφή τότε γίνεται εισαγωγή με την ένωση
    των στοιχείων των 2 αντικειμένων. Εάν υπάρχει εγγραφή γίνεται ενημέρωση 
    όλων των στοιχείων χωρίς κανένα έλεγχο. Δεν είναι επιθυμητή η διαγραφή
    σε καμμία περίπτωση.
     */
    public static boolean SaveAirportFlightsTableToDB(Airport a,
                                        Connection con) throws SQLException {
        if (a == null || con == null) {
            return false;
        }
        Statement stmt = null;
        String sqlselect;
        ResultSet rs = null;
        FlightsTable ft = a.getFlightsTable();
        int noOfAirportsInDB = 0;
        int rowsAffected = 0;
        // get HOUR_OF_DAY
        Calendar c = Calendar.getInstance();
        c.setTime(a.getStartDateTime());
        int c_HourOfDay = c.get(Calendar.HOUR_OF_DAY);
        try {
            // Έλεγχος ύπαρξης εγγραφής στον πίνακα AIRPORT
            stmt = con.createStatement();
            sqlselect = "SELECT COUNT(*)\n" +
                        "FROM AIRPORT";
            rs = stmt.executeQuery(sqlselect);
            rs.next();
            noOfAirportsInDB = rs.getInt(1);
            if (noOfAirportsInDB == 0) { // insert record
                sqlselect = "INSERT INTO AIRPORT\n" +
                            "  ( STARTTIME,\n" +
                            "    OPERATIONDURATION,\n" +
                            "    TIMESLOTDURATION,\n" +
                            "    RUNWAYS,\n" +
                            "    FT_DISPLAYLINES,\n" +
                            "    FT_RECENTLYDEPARTEDFLIGHTS,\n" +
                            "    FT_RECENTLYCANCELLEDFLIGHTS,\n" +
                            "    FT_REFRESHPERIOD )\n" +
                            "  VALUES(" + c_HourOfDay + ",\n" +
                        a.getOperationDuration() + ",\n" +
                        a.getTimeSlotDuration() + ",\n" +
                        a.getRunways() + ",\n" +
                        ft.getDisplayLines() + ",\n" +
                        ft.getMaxRecentlyDepartedFlightsToDisplay() + ",\n" +
                        ft.getMaxRecentlyCancelledFlightsToDisplay() + ",\n" +
                        ft.getRefreshTime() + ")";
                rowsAffected = stmt.executeUpdate(sqlselect);
                if (rowsAffected != 1) { // check permissions and DB availability
                    return false;
                }
            } else if (noOfAirportsInDB == 1) { // update record
                // delete existing record
                stmt.execute("DELETE AIRPORT");
                // insert updated record
                sqlselect = "INSERT INTO AIRPORT\n" +
                            "  ( STARTTIME,\n" +
                            "    OPERATIONDURATION,\n" +
                            "    TIMESLOTDURATION,\n" +
                            "    RUNWAYS,\n" +
                            "    FT_DISPLAYLINES,\n" +
                            "    FT_RECENTLYDEPARTEDFLIGHTS,\n" +
                            "    FT_RECENTLYCANCELLEDFLIGHTS,\n" +
                            "    FT_REFRESHPERIOD )\n" +
                            "  VALUES(" + c_HourOfDay + ",\n" +
                        a.getOperationDuration() + ",\n" +
                        a.getTimeSlotDuration() + ",\n" +
                        a.getRunways() + ",\n" +
                        ft.getDisplayLines() + ",\n" +
                        ft.getMaxRecentlyDepartedFlightsToDisplay() + ",\n" +
                        ft.getMaxRecentlyCancelledFlightsToDisplay() + ",\n" +
                        ft.getRefreshTime() + ")";
                rowsAffected = stmt.executeUpdate(sqlselect);
                if (rowsAffected != 1) { // check permissions and DB availability
                    return false;
                }
            } else { // ERROR - more than 1 airport in DB!!!
                return false;
            }
        }
         catch (SQLException e) {
             return false;
        } finally {
            // close open objects
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
        }
        return true;
    }
    
    /* Δημιουργεί και επιστρέφει ένα ArrayList από Airline από τη ΒΔ και για κάθε
       Airline δημιουργεί από τη ΒΔ τα Flight που της αντιστοιχούν
     */
    public static ArrayList<Airline> ReadAirlinesWithFlightsFromDB(Connection con) throws SQLException, IOException, ParseException, Exception {
        Statement stmt = null;
        String sqlselect;
        ResultSet rs = null;
        ArrayList<Airline> airlineList = new ArrayList<>();
        Airline a = null;
        try {
            stmt = con.createStatement();
            sqlselect = "SELECT CODE FROM AIRLINE";
            rs = stmt.executeQuery(sqlselect);
            while (rs.next()) {
                a = new Airline(rs.getString(1), con);
                airlineList.add(a);
            }
        } catch (SQLException e) {
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
        }
        return airlineList;
    }

    /* Αποθηκεύει στη ΒΔ μια λίστα από Airline μαζί και τα Flight
       που της αντιστοιχούν. 
       1) Αρχικά ελέγχουμε εάν στη ΒΔ υπάρχουν 
       Airline που πρέπει να διαγραφούν και τις διαγράφουμε. Αυτόματα
       με τη ρύθμιση Cascade Delete θα διαγραφούν και τα Flight που
       σχετίζονται.
       2) Γίνονται update οι υπόλοιπες Airline. Συγκεκριμένα μόνο το Name
          μπορεί να έχει αλλάξει!
       3) Κατόπιν ελέγχουμε εάν χρειάζεται να εισάγουμε κάποια Airline
     */
    public static boolean SaveAirlinesWithFlightsToDB(ArrayList<Airline> airlineList, Connection con) throws SQLException {
        Statement stmt = null;
        int rowsAffected = 0;
        String code = "", airline_code = "";
        int i;
        boolean found;
        Airline a;
        Flight f;
        // Δημιουργία πλήρους (αταξινόμητης) λίστας πτήσεων όλων των Airline
        ArrayList<Flight> flightList = new ArrayList<>();
        Iterator<Airline> ita = airlineList.iterator();
        Iterator<Flight> itf;
        while (ita.hasNext()) {
            a = ita.next();
            flightList.addAll((Collection)a.getFlightsList());
        }
        try {
            // Διαγραφή άχρηστων Airline
            stmt = con.createStatement();
            rowsAffected = stmt.executeUpdate("DELETE FROM AIRLINE\n" +
                                             "WHERE CODE NOT IN (" +
                            basics.Control.listAirlineCodes(airlineList) + ")");
            // Τροποποίηση υπαρχόντων Airline
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                                ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("SELECT NAME, CODE FROM AIRLINE");
            ArrayList<String> storedAirlineCodeList = new ArrayList<>();
            while (rs.next()) {
                /* αν ο CODE του current record υπάρχει στο airlineList,
                   κάνουμε UPDATE
                */
                code = rs.getString(2);
                storedAirlineCodeList.add(code); // used for inserts later on!
                found = false;
                for (i=0; i<airlineList.size(); i++)
                    if (airlineList.get(i).getCode().equals(code)) {
                        found = true;
                        break;
                    }
                if (found) { // UPDATE
                    rs.updateString(1, airlineList.get(i).getName());
                    rs.updateRow();
                }
            }
            // Εισαγωγή νέων Airline
            ita = airlineList.iterator();
            while (ita.hasNext()) {
                /* αν το Airline.code δεν υπάρχει στο storedAirlineCodeList,
                   κάνουμε INSERT
                */
                a = ita.next();
                code = a.getCode();
                found = false;
                for (i=0; i<storedAirlineCodeList.size(); i++)
                    if (storedAirlineCodeList.get(i).equals(code)) {
                        found = true;
                        break;
                    }
                if (!found) { // INSERT
                    rs.moveToInsertRow();
                    rs.updateString(1, a.getName());
                    rs.updateString(2, a.getCode());
                    rs.insertRow();
                    rs.beforeFirst();
                }
            }
            // Διαγραφή άχρηστων Flight
            stmt = con.createStatement();
            rowsAffected = stmt.executeUpdate("DELETE FROM FLIGHT\n" +
                "WHERE (CODE, AIRLINE_CODE) NOT IN (" +
                            basics.Control.listFlightCodes(flightList) + ")");    
            // Τροποποίηση υπαρχόντων Flight
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                                ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery("SELECT CODE, AIRLINE_CODE, DEPARTURETO,\n" +
                                    "       VIA, STATUS, SCHEDULEDEPARTURE,\n" +
                                    "       SCHEDULEDSLOT, EXPECTEDSLOT\n" +
                                    "FROM FLIGHT");
            ArrayList<String> storedFlightCodeList = new ArrayList<>();
            while (rs.next()) {
                /* αν το (CODE, AIRLINE_CODE) του current record υπάρχει 
                   στο flightList,  κάνουμε UPDATE
                */
                code = rs.getString(1);
                airline_code = rs.getString(2);
                storedFlightCodeList.add(code + " " + airline_code); // used for inserts later on!
                found = false;
                for (i=0; i<flightList.size(); i++)
                    if ((flightList.get(i).getCode().equals(code)) &&
                        (flightList.get(i).getAirline().getCode().equals(airline_code))) {
                        found = true;
                        break;
                    }
/* TODO : Κανονικά δεν θα έπρεπε να γίνονται update τα πεδία
          status, schecduledTimeSlot και expectedTimeSlot */
                if (found) { // UPDATE
                    rs.updateString(3, flightList.get(i).getDepartureTo());
                    rs.updateString(4, flightList.get(i).getVia());
                    rs.updateString(5, flightList.get(i).getStatus().toString());
                    rs.updateTimestamp(6, new Timestamp(flightList.get(i).getInitialSchedDeparture().getTime()));
                    if (flightList.get(i).getScheduledTimeSlot() != null)
                        rs.updateTimestamp(7, new Timestamp(flightList.get(i).getScheduledTimeSlot().getTime()));
                    if (flightList.get(i).getExpectedTimeSlot() != null)
                    rs.updateTimestamp(8, new Timestamp(flightList.get(i).getExpectedTimeSlot().getTime()));
                    rs.updateRow();
                }
            }
            // Εισαγωγή νέων Flight
            itf = flightList.iterator();
            while (itf.hasNext()) {
                /* αν το (CODE, AIRLINE_CODE) του current record δεν υπάρχει 
                   στο flightList,  κάνουμε INSERT
                */
                f = itf.next();
                code = f.getCode();
                airline_code = f.getAirline().getCode();
                found = false;
                for (i=0; i<storedFlightCodeList.size(); i++)
                    if (storedFlightCodeList.get(i).equals(code + " " + airline_code)) {
                        found = true;
                        break;
                    }
                if (!found) { // INSERT
                    rs.moveToInsertRow();
                    rs.updateString(1, f.getCode());
                    rs.updateString(2, f.getAirline().getCode());
                    rs.updateString(3, f.getDepartureTo());
                    rs.updateString(4, f.getVia());
                    rs.updateString(5, f.getStatus().toString());
                    if (f.getInitialSchedDeparture() != null)
                        rs.updateTimestamp(6, new Timestamp(f.getInitialSchedDeparture().getTime()));
                    if (f.getScheduledTimeSlot() != null)
                        rs.updateTimestamp(7, new Timestamp(f.getScheduledTimeSlot().getTime()));
                    if (f.getExpectedTimeSlot() != null)
                        rs.updateTimestamp(8, new Timestamp(f.getExpectedTimeSlot().getTime()));
                    rs.insertRow();
                    rs.beforeFirst();
                }
            }
        } catch(SQLException e) {
            return false;
        } finally {
            if (stmt != null) stmt.close();
        }
        return true;
    }
}
