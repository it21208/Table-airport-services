/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thread;

import GUI.frmFlightTable;
import GUI.frmMain;
import basics.Airport;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 */
public class ThreadAssist implements Runnable {
    
    private final Airport airport;
    private final frmMain mainFrame;

    public ThreadAssist(Airport airport, frmMain mainFrame) {
        this.airport = airport;
        this.mainFrame = mainFrame;
    }
    
    @Override
    public void run() {
        /* randomize initial scheduled departures in the range
            airport.start < x < airport.close
        */
        frmFlightTable flightTableFrame =
                new frmFlightTable(this.airport.getFlightsTable().getDisplayLines(),
                this.mainFrame);
        flightTableFrame.setVisible(true);
        try {
            /* Β2. Ανάθεση κατάλληλων χρονοθυρίδων στις πτήσεις */
            this.airport.assignTimeSlotsToFlights();
            // Β3. Τρέχει ένα πρώτο κύκλο για 1 λεπτό (OnTime --> Boarding)
            airport.getFlightsTable().runForPeriod(this.airport.getOperationDuration()*60, flightTableFrame);       
            // Β4. Κάνει Delay την πρώτη OnTime πτήση
            //Control.DelayTheFirstOnTimeFlight(airport);
            // Β5. Τρέχει ένα δεύτερο κύκλο για 60 λεπτά (Boarding --> Departed)
            //airport.getFlightsTable().runForPeriod(1, flightTableFrame);      
        } catch (Exception ex) {
            Logger.getLogger(frmMain.class.getName()).log(Level.SEVERE, null, ex);
        }                
    }
}
