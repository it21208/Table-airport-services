/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package GUI;

import basics.FlightStatus;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Δημιουργεί την εναλλαγή background color σε μόνες/ζυγές γραμμές
 * και τον κατάλληλο χρωματισμό της κατάστασης των πτήσεων
 * 
 */
public class CustomTableRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable jtable, Object o, 
            boolean isSelected, boolean hasFocus, int row, int col) {
        Component c = super.getTableCellRendererComponent(jtable, o, isSelected, 
                hasFocus, row, col);
        if((row % 2) == 1) 
            c.setBackground(Color.cyan);
        else
            c.setBackground(Color.white);

        if (col == 7) {
            if (jtable.getValueAt(row, col).toString().equals(FlightStatus.OnTime.toString()))
                c.setForeground(Color.GREEN);
            else if (jtable.getValueAt(row, col).toString().equals(FlightStatus.Delayed.toString()))
                c.setForeground(Color.ORANGE);
            else if (jtable.getValueAt(row, col).toString().equals(FlightStatus.Boarding.toString()))
                c.setForeground(Color.BLACK);
            else if (jtable.getValueAt(row, col).toString().equals(FlightStatus.Departed.toString()))
                c.setForeground(Color.LIGHT_GRAY);
            else if (jtable.getValueAt(row, col).toString().equals(FlightStatus.Cancelled.toString()))
                c.setForeground(Color.RED);
            else
                c.setForeground(Color.BLACK);
        } else
            c.setForeground(Color.BLACK);
        return c;
    }
}
