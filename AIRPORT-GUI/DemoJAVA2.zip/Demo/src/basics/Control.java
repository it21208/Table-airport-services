package basics;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public abstract class Control {
    
    // ------------------ ΛΕΙΤΟΥΡΓΙΕΣ ------------------------------------
    
    /* Δημιουργεί μια πτήση για μια αεροπορική εταιρεία ζητώντας
     * τα στοιχεία από το πληκτρολόγιο
     */
    public static Flight ReadFlight(Airline airline) throws ParseException, Exception{
        Flight f;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("ΕΙΣΑΓΩΓΗ ΠΤΗΣΗΣ ΓΙΑ ΤΗΝ " + airline.getName());
        System.out.print("Κωδικός : ");
        String code = keyboard.nextLine();
        System.out.print("Προορισμός : ");
        String departureTo = keyboard.nextLine();
        System.out.print("Ενδιάμεσος : ");
        String via = keyboard.nextLine();
        System.out.print("Προγραμματισμένη αναχώρηση : ");
        String scheduledDeparture = keyboard.nextLine();
        f = new Flight(code, departureTo, via, scheduledDeparture, airline);
        airline.getFlightsList().add(f);
        return f;
    }
    
    /* Δημιουργεί μια αεροπορική εταιρεία ζητώντας
     * τα στοιχεία από το πληκτρολόγιο
     */
    public static Airline ReadAirline() throws IOException, ParseException, Exception{
        Scanner keyboard = new Scanner(System.in);
        System.out.println("ΕΙΣΑΓΩΓΗ ΑΕΡΟΠΟΡΙΚΗΣ ΕΤΑΙΡΕΙΑΣ");
        System.out.print("'Ονομα : ");
        String name = keyboard.nextLine();
        System.out.print("Κωδικός : ");
        String code = keyboard.nextLine();
        System.out.print("Όνομα αρχείου πτήσεων : ");
        String flightDataFile = keyboard.nextLine();
        return new Airline(name,code, flightDataFile); 
    }
       
    /* Κάνει την πρώτη OnTime πτήση Delayed προκειμένου να 
     * προσομοιάσει κάποιο πραγματικό γεγονός */
    public static void DelayTheFirstOnTimeFlight(Airport airport) throws Exception {
        Flight f;
        Iterator<Flight> itf = airport.getFlightsList(new FlightSortbyTimeSlot()).iterator();
        while (itf.hasNext()) {
            f = itf.next();
            if (f.getStatus() == FlightStatus.OnTime) {
                f.setStatus(FlightStatus.Delayed);
                return;
            }
        }
    }
    
    /* Επιστρέφει ένα String με τα Code των Airline με , ενδιάμεσα.
       πχ. 'Α3', 'ΟΑ'
       Χρησιμεύει σε SQL query, πχ.
            ...
            WHERE CODE NOT IN (@@@)
    */
    public static String listAirlineCodes(ArrayList<Airline> airlineList) {
        Iterator<Airline> it = airlineList.iterator();
        Airline a;
        String ret = "";
        while (it.hasNext()) {
            a = it.next();
            ret = ret + "'" + a.getCode() + "'";
            if (it.hasNext())
                ret = ret + ", ";
        }
        return ret;
    }

    /* Επιστρέφει ένα String με τα (Code, Airline_code) των Flight με , ενδιάμεσα.
       πχ. (561, 'Α3'), (2008, 'ΟΑ')
       Χρησιμεύει σε SQL query, πχ.
            ...
            WHERE (CODE, AIRLINE_CODE) NOT IN (@@@)
    */
    public static String listFlightCodes(ArrayList<Flight> flightList) {
        Iterator<Flight> it = flightList.iterator();
        Flight f;
        String ret = "";
        while (it.hasNext()) {
            f = it.next();
            ret = ret + "('" + f.getCode() + "', ";
            ret = ret + "'" + f.getAirline().getCode() + "')";
            if (it.hasNext())
                ret = ret + ", ";
        }
        return ret;
    }
}