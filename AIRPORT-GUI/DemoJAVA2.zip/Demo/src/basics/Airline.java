package basics;

import GUI.frmFlightTable;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

public class Airline {

    // --------------- ΓΝΩΡΙΣΜΑΤΑ ----------------------------------------
    private String name;  // ονομασία αεροπορικής εταιρείας
    private final String code;  // κωδικός 2 γραμμάτων αεροπ. εταιρείας
    private final String flightDataFile;  // ονομασία αρχείου πτήσεων
    private final ArrayList<Flight> flightsList;  /* λίστα πτήσεων */
    private Airport airport;  // αεροδρόμιο όπου δώθηκε η λίστα πτήσεων 
   
    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getFlightDataFile() {
        return flightDataFile;
    }

    public ArrayList<Flight> getFlightsList() {
        return flightsList;
    }

    public Airport getAirport() {
        return airport;
    }

    public void setAirport(Airport airport) {
        this.airport = airport;
    }
     
    // ------------ ΜΕΘΟΔΟΙ ΚΑΤΑΣΚΕΥΑΣΤΕΣ -------------------------------
    
    /* Κατασκευαστής 1 -------
     *  Δημιουργεί μια αεροπορική εταιρεία με ονομασία, κωδικό και
     *  το αρχείο των πτήσεών της. Αν δωθεί αρχείο πτήσεων διαβάζονται οι
     *  πληροφορίες των πτήσεων και δημιουργείται η λίστα πτήσεων
     */
    public Airline(String name, String code, String flightDataFile) 
            throws IOException, ParseException, Exception {
        // check if Code and Name values are not empty
        if (code.isEmpty() || name.isEmpty()) {
            throw new Exception("Airline constructor parameter(s)(Code, Name) empty");
        }   
        this.name = name;
        this.code = code;
        this.flightDataFile = flightDataFile;
        if (!flightDataFile.isEmpty()) // αν υπάρχει λίστα πτήσεων ..
            this.flightsList = this.ReadMyFlights();
        else // διαφορετικά ..
            this.flightsList = new ArrayList<>();
    }
    
    /* Κατασκευαστής 2 -------
     *  Δημιουργεί μια αεροπορική εταιρεία με κωδικό από τη ΒΔ. Από την
     *  παρεχόμενη σύνδεση στη ΒΔ διαβάζονται οι
     *  πληροφορίες των πτήσεων και δημιουργείται η λίστα πτήσεων
     */
    public Airline(String code, Connection con) 
            throws IOException, ParseException, SQLException, Exception {
        // get Airline info
        Statement stmt = null;
        String sqlselect, name = "";
        ResultSet rs = null;
        ArrayList<Flight> flightList = null;
        Flight f = null;
        try {
            // get airline name
            stmt = con.createStatement();
            sqlselect = "SELECT NAME FROM AIRLINE WHERE CODE='" + code + "'";
            rs = stmt.executeQuery(sqlselect);
            rs.next();
            name = rs.getString(1);
            // get airline flight list
            sqlselect = "SELECT CODE,\n" +
                             "  DEPARTURETO,\n" +
                             "  VIA,\n" +
                             "  SCHEDULEDEPARTURE\n" +
                        "FROM FLIGHT \n" +
                        "WHERE AIRLINE_CODE='" + code + "'";
            rs = stmt.executeQuery(sqlselect);
            flightList = new ArrayList<>();
            while(rs.next()) {
                f = new Flight(rs.getString(1), rs.getString(2),
                              (rs.getString(3) == null) ? "":rs.getString(3), 
                              Flight.formatter.format(rs.getTimestamp(4)),
                                          this);
                flightList.add(f);
            }
        } catch(SQLException | ParseException e) {
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
        }
        // assign data member values
        this.name = name;
        this.code = code;
        this.flightDataFile = "";
        this.flightsList = flightList;
    }

    // ------------------ ΛΕΙΤΟΥΡΓΙΕΣ ------------------------------------
    
    /* Επιστρέφει μια λίστα πτήσεων που τη δημιουργεί διαβάζοντας τις 
     * αντίστοιχες πληροφορίες από το αρχείο πτήσεων της εταιρείας. Καλείται
     * μόνο από τον Κατασκευαστή
     */
    private ArrayList<Flight> ReadMyFlights() throws IOException, ParseException, Exception {
        String code, departureTo, via, scheduledDeparture;
        BufferedReader in = null;
        Flight fl;
        Scanner sc = null;
        ArrayList<Flight> arrFlights = new ArrayList<>();
        try {
            in = new BufferedReader(new FileReader(this.flightDataFile));
            String line;
            while ((line = in.readLine()) != null) {
                /* ορίζεται το ", " ως delimiter για να διαβαστούν
                   4 πεδία σε κάθε γραμμή */
                sc = new Scanner(line).useDelimiter(",\\s");
                code = sc.next();
                departureTo = sc.next();
                via = sc.next();
                scheduledDeparture = sc.next();
                // δημιουργία της πτήσης για αυτήν την αεροπορική εταιρεία
                fl = new Flight(code, departureTo, via, scheduledDeparture, this);
                // προσθήκη της νέας πτήσης στη λίστα πτήσεων
                arrFlights.add(fl);
            }
        } finally { // κλείσιμο των stream που έχουν ανοίξει
            if (in != null) {
                in.close();
            }
            if (sc != null) {
                sc.close();
            }
        }
        return arrFlights;
    }
 
    @Override
    public String toString() {
        return String.format("%-10s | %-40s", this.code, this.name);
    }

    /**
     * Επιστρέφει ένα String πολλαπλών γραμμών όπου περιγράφονται τα 
     * στοιχεία της αεροπορικής εταιρείας στην 1η γραμμή και ακολούθως
     * σε ξεχωριστή γραμμή και indented τα στοιχεία της κάθε πτήσης της. 
     * Γενική χρήση πχ. έλεγχοι κατά τη διαδικασία ανάπτυξης
     */
    public String toStringExtended() {
        Flight f;
        String s = this.toString() + "\n";
        Iterator<Flight> it = this.flightsList.iterator();
        while (it.hasNext()) {
            s = s + "\t";
            f = it.next();
            s = s + f.toString();
            s = s + "\n";
        }
        return s;
    }
        
    /*
     * Για κάθε πτήση της αεροπορικής εταιρείας ελέγχει και 
     * κάνει τις χρονικά εξαρτώμενες (ολικώς ή μερικώς) μεταβάσεις:
     *          OnTime ||  
     *          Delayed     --> Boarding 
     *          Boarding    --> Departed ||
     *                          Cancelled
     */
    public void refreshStatusOfRemaining(frmFlightTable flightTableFrame) throws Exception {
        Flight f;
        Simulator sim = this.airport.getSimulator();
        Iterator<Flight> it = this.flightsList.iterator();
        while (it.hasNext()) {
            f = it.next();
            switch (f.getStatus()) {
                case OnTime: // εάν η πτήση είναι OnTime || Delayed 
                case Delayed:
                    // και ισχύει: (NOW <= ValidTimeSlot < NOW+30min)
                    if (sim.isDateDiffWithCurTimeLessThanMinutes(30,
                            f.getValidTimeSlot())) {
                        // η πτήση γίνεται Boarding
                        flightTableFrame.LogToGUI(
                            String.format("%s > Flight %s is BOARDING. Free runways = %d", 
                                Simulator.formatter.format(this.airport.getSimulator().getSimulatedTime()),
                                f.getFullCode(),
                                this.airport.getNoOfFreeRunways()));
                        f.setStatus(FlightStatus.Boarding);
                    }
                    break;
                case Boarding: // εάν η πτήση είναι Boarding
                    // και ισχύει: (ValidTimeSlot <= NOW < ValidTimeSlot+timeSlotDuration/2)
                    if (sim.isCurTimeDiffWithDateLessThanMinutes(this.airport.getTimeSlotDuration()/2, 
                            f.getValidTimeSlot())) {
                        // και υπάρχει ελεύθερος αεροδιάδρομος                 
                        if (this.airport.getNoOfFreeRunways() > 0) {
                            // η πτήση γίνεται Departed                            
                            f.setStatus(FlightStatus.Departed);
                            // και δεσμεύεται ένας αεροδιάδρομος
                            this.airport.setNoOfFreeRunways(this.airport.getNoOfFreeRunways()- 1);
                            flightTableFrame.LogToGUI(
                                String.format("%s > Flight %s is DEPARTING, allocating runway. Free runways = %d", 
                                    Simulator.formatter.format(this.airport.getSimulator().getSimulatedTime()),
                                    f.getFullCode(),
                                    this.airport.getNoOfFreeRunways()));
                        } else { /* αλλά δεν υπάρχει ελεύθερος αεροδιάδρομος
                            τότε η πτήση γίνεται Cancelled */
                            f.setStatus(FlightStatus.Cancelled);
                            flightTableFrame.LogToGUI(
                                String.format("%s > Flight %s failed to start DEPARTING!. No available runway! Free runways = %d", 
                                    Simulator.formatter.format(this.airport.getSimulator().getSimulatedTime()),
                                    f.getFullCode(),
                                    this.airport.getNoOfFreeRunways()));
                        }                       
                    }
                    break;
                default :
            }
        }    
    }
    
    /* Ελέγχει τις Departed πτήσεις της αεροπορικής εταιρείας για να
     * διαπιστώσει εάν είναι ώρα να απελευθερωθεί κάποιος διάδρομος
     */
    public void ReleaseAirwaysOfDepartedFlights(frmFlightTable flightTableFrame) throws Exception {
        Flight f;
        Simulator sim = this.airport.getSimulator();
        Iterator<Flight> it = this.flightsList.iterator();
        while (it.hasNext()) {
            f = it.next();
            switch (f.getStatus()) {
                case Departed: // εάν η πτήση είναι Departed 
                    /* και ισχύει: 
                       (ValidTimeSlot+1slot <= NOW < ValidTimeSlot+1slot+1/2slot) */
                    if (sim.isCurTimeDiffWithDateLessThanMinutes(this.airport.getTimeSlotDuration()/2, 
                            new Date(f.getValidTimeSlot().getTime() + 
                                this.airport.getTimeSlotDuration()*60*1000))) {
                        // και υπάρχει κάποιος δεσμευμένος διάδρομος
                        if (this.airport.getNoOfFreeRunways() < this.airport.getRunways()) {
                            // τότε απελευθέρωσε ένα διάδρομο
                            this.airport.setNoOfFreeRunways(this.airport.getNoOfFreeRunways()+ 1);
                            flightTableFrame.LogToGUI(
                                    String.format("%s > Flight %s has DEPARTED, releasing runway. Free runways = %d", 
                                            Simulator.formatter.format(this.airport.getSimulator().getSimulatedTime()),
                                            f.getFullCode(),
                                            this.airport.getNoOfFreeRunways()));
                        }
                    }
                    break;
                default :
            }
        }    
    }

    /*
        Απαραίτητο για να λειτουργήσει σωστά η μέθοδος indexOf σε
        ArrayList<Airline>, κυρίως όταν ελέγχουμε τη μοναδικότητα
        μιας airline στη λίστα.
        To πρωτεύων κλειδί της Airline είναι το Code!
    */
    @Override
    public boolean equals(Object o) {
        if ((o == null) ||
            (!(o instanceof Airline)))
            return false;
        if (o == this) return true;
        Airline a = (Airline)o;
        return (a.getCode().equals(this.getCode())) ;
    }
}

