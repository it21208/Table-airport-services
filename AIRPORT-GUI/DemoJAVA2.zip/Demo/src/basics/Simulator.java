/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package basics;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * This class can twist time so that it fits specific simulation needs.
 * It can produce "simulated current time" for all listening objects
 starting from an actual startSimDateTime
 */
public class Simulator {
    // --------------- ΓΝΩΡΙΣΜΑΤΑ ----------------------------------------
    public static final int STANDARD_RATIO = 30;
    public static DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
    private Date creationDateTime; // χρονική στιγμή εκκίνησης simulator
    private Date startSimDateTime; // χρονική στιγμή έναρξης εικονικού ρολογιού
    private long msecsStartSimDateTime; // msecs του startSimDateTime-EPOC
    private Calendar simCalendar; // calendar για υπολογισμούς με εικονικό ρολόι
    private int simToActualSecRatio; // 1:simToActualSecRatio
    private Airport airport;
    
    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------

    public Date getStartSimDateTime() {
        return startSimDateTime;
    }

    /**
     * Η χρονική στιγμή έναρξης του εικονικού ρολογιού πρέπει να βρίσκεεται
     * μέσα στα όρια λειτουργίας του Airport
     * @param startSimDateTime 
     */
    public void setStartSimDateTime(Date startSimDateTime) throws Exception {
        Calendar c = Calendar.getInstance();
        c.setTime(startSimDateTime);
        c.add(Calendar.SECOND, 2);
        Date tmp = c.getTime();
        if ((this.airport.getStartDateTime().after(tmp)) ||
                (this.airport.getEndDateTime().before(tmp)))
            throw new Exception("Simulator start date-time must be within the airport's operating hours!");
        this.startSimDateTime = startSimDateTime;
    }

    public Calendar getCalendar() {
        return simCalendar;
    }

    public int getSimsecToactualsecRatio() {
        return simToActualSecRatio;
    }

    public void setSimsecToactualsecRatio(int simsecToactualsecRatio) throws Exception {
        if (simsecToactualsecRatio >= 1)
            this.simToActualSecRatio = simsecToactualsecRatio;
        else
            throw new Exception("Simulated to Actual seconds ratio can not be < 1");
    }

    public Airport getAirport() {
        return airport;
    }

    public void setAirport(Airport airport) {
        this.airport = airport;
    }

    // ------------ ΜΕΘΟΔΟΙ ΚΑΤΑΣΚΕΥΑΣΤΕΣ -------------------------------
    /* Κατασκευαστής 1 -------
     *  Δημιουργεί ένα simulator με συγκεριμένη ώρα έναρξης και
     *  αναλογία εικονικών προς πραγματικών δευτερολέπτων. Όταν δωθεί
     *  null στο startSimDateTime υποθέτει το NOW
     */
    public Simulator(Date startSimDateTime, int simsecToactualsecRatio) throws Exception {
        this.startSimDateTime = startSimDateTime;
        this.setSimsecToactualsecRatio(simsecToactualsecRatio);
    }

    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------
    
    /* 
     *  Δημιουργεί ένα simulator με συγκεριμένη ώρα έναρξης και
     *  αναλογία εικονικών προς πραγματικών δευτερολέπτων. Όταν δωθεί
     *  null στο startSimDateTime υποθέτει το NOW
     */
     public void Start() throws Exception {
        this.simCalendar = Calendar.getInstance(); // current date time
        this.creationDateTime = this.simCalendar.getTime();
        this.simCalendar.setTime(this.startSimDateTime);
        // αποθηκεύω το date που υπάρχει στο simCalendar
        this.setStartSimDateTime(simCalendar.getTime());
        // υπολογίζω το start date time σε msecs για λόγους απόδοσης
        this.msecsStartSimDateTime = this.simCalendar.getTimeInMillis();
    }
    /**
     * 
     * @return Επιστρέφει το εικονικό NOW του simulator
     */
    public Date getSimulatedTime() throws Exception {
        Calendar calNow = Calendar.getInstance();
        /* υπολογίζουμε το dt σε msecs πραγματικού χρόνου από την έναρξη του
           simulator μέχρι NOW */
        long actualMSecsUntilNow = 
                calNow.getTimeInMillis() - this.creationDateTime.getTime();
        // υπολογίζουμε τα truncated secs του dt
        int actualSecsTruncatedNow = (int) (actualMSecsUntilNow/1000);
        // υπολογίζουμε τα remaining msecs του dt
        int actualMSecsRemainderNow = (int) (actualMSecsUntilNow % 1000);
        /* αντιγράφω στο προσωρινό calendar την τιμή του calendar του simulator */
        calNow.setTimeInMillis(this.msecsStartSimDateTime);
        /* προσθέτω τα secs εικονικού χρόνου στο προσωρινό calendar */
        calNow.add(Calendar.SECOND, actualSecsTruncatedNow*this.simToActualSecRatio);
        /* προσθέτω τα msecs εικονικού χρόνου στο προσωρινό calendar */
        calNow.add(Calendar.MILLISECOND, actualMSecsRemainderNow*this.simToActualSecRatio);
        // επιστρέφουμε το εικονικό NOW
        return calNow.getTime();
    }
    
    public long getSimMSecs(long ActMSecs) {
        return ActMSecs*this.simToActualSecRatio;
    }
    
    public long getSimSecs(long ActSecs) {
        return ActSecs*this.simToActualSecRatio;
    }

    public long getSimMins(long ActMins) {
        return ActMins*this.simToActualSecRatio;
    }
    
    public long getSimHrs(long ActHrs) {
        return ActHrs*this.simToActualSecRatio;
    }

    public long getActMSecs(long SimMSecs) {
        return SimMSecs/this.simToActualSecRatio;
    }
    
    public double getActSecs(long SimSecs) {
        return ((double)SimSecs)/this.simToActualSecRatio;
    }

    public double getActMins(long SimMins) {
        return ((double)SimMins)/this.simToActualSecRatio;
    }
    
    public double getActHrs(long SimHrs) {
        return ((double)SimHrs)/this.simToActualSecRatio;
    }

    /**
     * 
     * @return Επιστρέφει το μεγαλύτερο από τo πραγματικό και εικονικό NOW
     */
    public Date getMaxActNOW_SimNOW() throws Exception {
        Date SimNOW = this.getSimulatedTime();
        Date ActNOW = (Calendar.getInstance()).getTime();
        if (SimNOW.after(ActNOW))
            return SimNOW;
        else
            return ActNOW;
    }
    
    /* Επιστρέφει true εάν:
     *   dt <= NOW < dt+simMins
     */
    public boolean isCurTimeDiffWithDateLessThanMinutes
        (long simMins, Date dt) throws Exception {
        // βρίσκει τα msec της τρέχουσας ημέρας και ώρας
        long msecsNow = this.getSimulatedTime().getTime();
        // βρίσκει τα msec του dt
        long msecsdt = dt.getTime();
        // Αν δεν ικανοποιείται η αριστερή ανισότητα dt <= now
        // επιστροφή με false
        if (msecsNow < msecsdt)
            return false;
        // βρίσκει τα ActMins
        double ActMins = this.getActMins(simMins);
        // βρίσκει τη διαφορά (NOW - dt) σε min
        double minDiff = ((double)(msecsNow - msecsdt))/(60000);
        // επιστρέφει το αποτέλεσμα της σύγκρισης
        return minDiff < simMins;
    }

    /* Επιστρέφει true εάν:
     *   dt <= NOW < dt+simHrs
     */
    public boolean isCurTimeDiffWithDateLessThanHours
        (int simHrs, Date dt) throws Exception {
        return isCurTimeDiffWithDateLessThanMinutes(simHrs*60, dt);
    }

    /* Επιστρέφει true εάν:
     *   NOW <= dt < NOW+simMins
     */
    public boolean isDateDiffWithCurTimeLessThanMinutes
        (long simMins, Date dt) throws Exception {
        long msecsNow, msecsdt;
        double ActMins, minDiff=0.0;
        try {
            // βρίσκει τα msec της τρέχουσας ημέρας και ώρας
             msecsNow = this.getSimulatedTime().getTime();
             // βρίσκει τα msec του dt
             msecsdt = dt.getTime();
             // Αν δεν ικανοποιείται η αριστερή ανισότητα NOW <= dt
             // επιστροφή με false
             if (msecsdt < msecsNow)
                 return false;
             // βρίσκει τα ActMins
             ActMins = this.getActMins(simMins);
             // βρίσκει τη διαφορά (NOW - dt) σε min
             minDiff = ((double)(msecsdt - msecsNow))/(60000);
        } catch (Exception e) {
            System.out.println("isDateDiffWithCurTimeLessThanMinutes " + e.getMessage());
        } finally {
            // check if minDiff is less than <minutes> parameter and return 
            // the result
            return minDiff < simMins;
        }
    }
}
