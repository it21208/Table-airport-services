package basics;

import GUI.frmFlightTable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import javax.swing.JTable;

public class FlightsTable {

    // --------------- ΓΝΩΡΙΣΜΑΤΑ ----------------------------------------
    private final int displayLines; // πλήθος γραμμών πίνακα
    private final int maxRecentlyDepartedFlightsToDisplay;    /* μέγιστο 
            * πλήθος Departed πτήσεων που μπορούν να εμφανίζονται */
    private final int maxRecentlyCancelledFlightsToDisplay;   /* μέγιστο
            * πλήθος Cancelled πτήσεων που μπορούν να εμφανίζονται */
    private final int refreshTime;  // ανανέωση πίνακα κάθε .. min
    private final Airport airport;  // το αεροδρόμιο στο οποίο ανήκει

    // ------------ ΜΕΘΟΔΟΙ ΠΡΟΣΒΑΣΗΣ-ΤΡΟΠΟΠΟΙΗΣΗΣ -----------------------
    public int getDisplayLines() {
        return displayLines;
    }

    public int getMaxRecentlyDepartedFlightsToDisplay() {
        return maxRecentlyDepartedFlightsToDisplay;
    }

    public int getMaxRecentlyCancelledFlightsToDisplay() {
        return maxRecentlyCancelledFlightsToDisplay;
    }

    public int getRefreshTime() {
        return refreshTime;
    }

    public Airport getAirport() {
        return airport;
    }
    
    // ------------ ΜΕΘΟΔΟΙ ΚΑΤΑΣΚΕΥΑΣΤΕΣ -------------------------------
    
    /* Κατασκευαστής 1 -------
     * Δημιουργεί ένα ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ για ένα αεροδρόμιο και ορίζει το
     * πλήθος γραμμών που εμφανίζει, το μέγιστο πλήθος Delayed και
     * Cancelled πτήσεων που μπορεί να εμφανίζει και το χρόνο ανανέωσης
     */
    public FlightsTable(int displayLines, int maxRecentlyDepartedFlightsToDisplay, 
            int maxRecentlyCancelledFlightsToDisplay, int refreshTime,
            Airport airport) {
        this.displayLines = displayLines;
        this.maxRecentlyDepartedFlightsToDisplay = maxRecentlyDepartedFlightsToDisplay;
        this.maxRecentlyCancelledFlightsToDisplay = maxRecentlyCancelledFlightsToDisplay;
        this.refreshTime = refreshTime;
        this.airport = airport;
        this.airport.setFlightsTable(this);
    }

    // ------------------ ΛΕΙΤΟΥΡΓΙΕΣ ------------------------------------

    /*  Εκτελεί μια προσομοίωση του ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ για περίοδο κάποιων
     *  λεπτών (min).
     */
    public void runForPeriod(int minutes,
            frmFlightTable flightTableFrame) throws InterruptedException, Exception {
        /* υπολογισμός αριθμού επαναλήψεων (το πηλίκο είναι ίδιο και για
           πραγματικά και για εικονικά διαστήματα */
        int repetitions = minutes/refreshTime;
        // simulated msecs για αναμονή μεταξύ refresh του ΠΙΝΑΚΑ
        long msecsToSleep = this.airport.getSimulator().getActMSecs(this.refreshTime*60000);
        // Log to GUI
        flightTableFrame.LogToGUI(
                String.format("Start of Simulation (1:%d) run for Period %d min, %d repetitions, %d msecs sleep",
                        this.airport.getSimulator().getSimsecToactualsecRatio(),
                        minutes, repetitions, msecsToSleep));
        // σε κάθε επανάληψη
        for (int i=1; i<=repetitions; i++) {
            // κάνε ανανέωση της κατάστασης του ΠΙΝΑΚΑ
            this.refreshStatus(flightTableFrame);
            // περίμενε για διάστημα refreshTime
            Thread.sleep(msecsToSleep);
        }
        flightTableFrame.LogToGUI(
                String.format("End of Simulation (1:%d) run",
                        this.airport.getSimulator().getSimsecToactualsecRatio()));
    }
        
    /* Κάνει ανανέωση του ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ.
     * Είναι το κυρίως κομμάτι της προσομοίωσης
     */
    private void refreshStatus(frmFlightTable flightTableFrame) throws Exception {
        /* 1. καλούνται όλες οι αεροπορικές εταιρείες να ενημερώσουν πόσες
              από τις Departed πτήσεις τους έχουν "πετάξει" και άρα είναι
              δυνατόν να απελευθερωθούν οι αντίστοιχοι διάδρομοι */
        Airline a;
        Iterator<Airline> it = this.airport.getAirlinesList().iterator();
        while (it.hasNext()) {
            a = it.next();
            a.ReleaseAirwaysOfDepartedFlights(flightTableFrame);
        }
        /* 2. καλούνται όλες οι αεροπορικές εταιρείες να ενημερώσουν την 
              κατάσταση των υπόλοιπων πτήσεών τους */
        it = this.airport.getAirlinesList().iterator();
        while (it.hasNext()) {
            a = it.next();
            a.refreshStatusOfRemaining(flightTableFrame);
        }
        // 3. δημιουργία της λίστας πτήσεων του ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ
        ArrayList<Flight> flightsDisplayList = this.getFlightsDisplayList();
        Collections.sort(flightsDisplayList, new FlightSortbyTimeSlot());
        // 4. εμφάνιση του ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ
        //this.printCONSOLEFlightDisplayList(flightsDisplayList);
        // 5. create gui
        this.printGUIFlightDisplayList(flightTableFrame, flightsDisplayList);
    }

    /**
     * 
     * @return Τη λίστα με τις Departed και Cancelled flights
     */
    private ArrayList<Flight> getDepartedAndCancelledDisplayList() throws Exception {
        Flight f;
        Simulator sim = this.airport.getSimulator();
        boolean isDeparted, isCancelled, hasLeft1Hour, hasLeft6Hours;
        int maxRecentlyDepartedFlightsToDisplay = 
                this.maxRecentlyDepartedFlightsToDisplay;
        int maxRecentlyCancelledFlightsToDisplay = 
                this.maxRecentlyCancelledFlightsToDisplay;

        /* 1. αντιγραφή της λίστας πτήσεων αεροδρομίου και ταξινόμηση σε
          φθίνουσα σειρά με βάση το κατά σύμβαση κριτήριο getValidTimeSlot() */
        ArrayList<Flight> flightsList = (ArrayList<Flight>)this.airport.getFlightsList(null);
        Collections.reverse(flightsList);
        /* 2. δημιουργία νέας λίστας μόνο με τις πτήσεις που ικανοποιούν τις
           συνθήκες:
                    Departed (< 1 hour)     ή 
                    Cancelled (6 < hours)
            Όσες πτήσεις προστίθενται στη νέα λίστα, αφαιρούνται από το
            αντίγραφο της λίστας που δημιουργήθηκε!  */
        ArrayList<Flight> departedAndCancelledFlightsList = new ArrayList<>();
        Iterator<Flight> it = flightsList.iterator();
        while (it.hasNext()) {
            f = it.next();
            isDeparted = f.getStatus().equals(FlightStatus.Departed);
            isCancelled = f.getStatus().equals(FlightStatus.Cancelled);
            hasLeft1Hour = 
                    sim.isCurTimeDiffWithDateLessThanHours(1, 
                            f.getValidTimeSlot());
            hasLeft6Hours = 
                    sim.isCurTimeDiffWithDateLessThanHours(6, 
                            f.getValidTimeSlot());
            if (isDeparted)
                if (hasLeft1Hour && (maxRecentlyDepartedFlightsToDisplay-- > 0))
                    departedAndCancelledFlightsList.add(f);
            if (isCancelled) 
                if (hasLeft6Hours && (maxRecentlyCancelledFlightsToDisplay-- > 0))
                    departedAndCancelledFlightsList.add(f);
        }
        return departedAndCancelledFlightsList;
    }
    
     /*  Δημιουργεί τη λίστα πτήσεων του ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ
      */
    public ArrayList<Flight> getFlightsDisplayList() throws Exception {
        Flight f;
        ArrayList<Flight> flightsList, flightsDisplayList, departedAndCancelledFlightsList;
        int remainingDisplayLines = this.displayLines;
        // Βρίσκω τη λίστα με τις Departed και Cancelled flights
        departedAndCancelledFlightsList = this.getDepartedAndCancelledDisplayList();
        // Μειώνω τις διαθέσιμες γραμμές του πίνακα πτήσεων
        remainingDisplayLines -= departedAndCancelledFlightsList.size();
        // δημιουργία Λίστας Πτήσεων του Πίνακα
        flightsDisplayList = new ArrayList<>();
        /* στη Λίστα Πτήσεων Πίνακα προσθέτω πρώτα τη λίστα με τις
           Departed και Cancelled
        */
        flightsDisplayList.addAll((Collection)departedAndCancelledFlightsList);
        /* Στη νέα λίστα προστίθενται και οι πτήσεις (εκτός Departed και 
           Cancelled) που η χρονοθυρίδα τους είναι πιο κοντά στην τρέχουσα 
           χρονική στιγμή αλλά μέχρι το όριο των γραμμών του 
           ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ */
        flightsList = this.airport.getFlightsList(new FlightSortbyTimeSlot());
        Iterator<Flight> it = flightsList.iterator();
        while (it.hasNext() && (remainingDisplayLines > 0)) {
            f = it.next();
            if ((f.getStatus() != FlightStatus.Departed) && 
                (f.getStatus() != FlightStatus.Cancelled)) {
                flightsDisplayList.add(f);
                remainingDisplayLines--;
            }
        }
        // 4. Επιστρέφει τη νέα λίστα πτήσεων του ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ
        return flightsDisplayList;
    }
          
    /* Εμφανίζει τη λίστα πτήσεων που δίνεται στον ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ
     */
    private void printGUIFlightDisplayList(frmFlightTable flightTableFrame,
            ArrayList<Flight> flightsDisplayList) throws Exception {
        int row = 0;
        int cols = 8;     
        Iterator<Flight> it = flightsDisplayList.iterator();
        JTable tbl = flightTableFrame.getTableFlights();
        Flight f;
        // εμφάνιση των πτήσεων της λίστας - μπορεί να είναι < displayLines
        while(it.hasNext()) {
            f = it.next();
            tbl.setValueAt(f.getDepartureTo(), row, 0);
            tbl.setValueAt(f.getAirline().getName(), row, 1);
            tbl.setValueAt(f.getFullCode(), row, 2);
            tbl.setValueAt(f.getVia(), row, 3);
            if (f.getExpectedTimeSlot() != null)
                tbl.setValueAt(Flight.formatter.format(f.getExpectedTimeSlot()), row, 4);
            else
                tbl.setValueAt("", row, 4);
            if (f.getScheduledTimeSlot() != null) 
                tbl.setValueAt(Flight.formatter.format(f.getScheduledTimeSlot()), row, 5);
            else
                tbl.setValueAt("", row, 5);
            if (f.getInitialSchedDeparture() != null)
                tbl.setValueAt(Flight.formatter.format(f.getInitialSchedDeparture()), row, 6);
            else
                tbl.setValueAt("", row, 6);
            tbl.setValueAt(f.getStatus().toString(), row, 7);
            row++;
        }
        // καθαρισμός των υπόλοιπων γραμμών
        while (row < this.displayLines) {
            tbl.setValueAt("", row, 0);
            tbl.setValueAt("", row, 1);
            tbl.setValueAt("", row, 2);
            tbl.setValueAt("", row, 3);
            tbl.setValueAt("", row, 4);
            tbl.setValueAt("", row, 5);
            tbl.setValueAt("", row, 6);
            tbl.setValueAt("", row, 7);
            row++;
        }
        flightTableFrame.getLblCurrentTime().setText(String.format("Current(simulated) Time: %1$tH:%1$tM:%1$tS%2$122s", 
                this.airport.getSimulator().getSimulatedTime(),""));
    }
    
    /* Εμφανίζει τη λίστα πτήσεων που δίνεται στον ΠΙΝΑΚΑ ΑΝΑΧΩΡΗΣΕΩΝ
     */
    private void printCONSOLEFlightDisplayList(ArrayList<Flight> flightsDisplayList) throws Exception {
        Flight f;
        int lineNo = 1;
        String columnsFormat = "%-25s%-20s%-10s%-25s%-20s%-20s%-20s%-15s\n";
        Iterator<Flight> it = flightsDisplayList.iterator();
        String displayLine = "";
        
        // 1. Καθαρισμός οθόνης και τοποθέτηση άνω-αριστερά
        displayLine += EscSeq.ClearScreen;
        displayLine += "\033[37;45m";
        displayLine += String.format(columnsFormat, 
                "DEPARTURES", "AIRLINE", "FLIGHT", "VIA", 
                "EXPECTED", "SLOT", "SCHEDULED", "REMARKS");
        displayLine += String.format(columnsFormat, 
                "", "", "", "", 
                "DEPARTURE", "", "DEPARTURE", "");
        
        displayLine += EscSeq.Reset; // επαναφορά στο κανονικό
        while (it.hasNext()) {
            f = it.next();
            displayLine += (lineNo++ % 2 == 1) ? "\033[30;46m" : "\033[30;47m";
            displayLine += String.format(columnsFormat, 
                f.getDepartureTo(), f.getAirline().getName(), f.getCode(), 
                (f.getVia().isEmpty() ? "" : f.getVia()), 
                (f.getExpectedTimeSlot() == null ) ? 
                        "" : Flight.formatter.format(f.getExpectedTimeSlot()),
                (f.getScheduledTimeSlot() == null) ?
                        "" : Flight.formatter.format(f.getScheduledTimeSlot()),
                (f.getInitialSchedDeparture() == null) ?
                        "" : Flight.formatter.format(f.getInitialSchedDeparture()), 
                f.getStatus().toColouredString());
            displayLine += EscSeq.Reset;
        }
        displayLine += "\033[37;45m";
        displayLine += String.format("Current(simulated) Time: %1$tH:%1$tM:%1$tS%2$122s", this.airport.getSimulator().getSimulatedTime(),"");
        displayLine += EscSeq.Reset;
        System.out.println(displayLine);
//        System.out.println(this.airport.toString());
    }
}
