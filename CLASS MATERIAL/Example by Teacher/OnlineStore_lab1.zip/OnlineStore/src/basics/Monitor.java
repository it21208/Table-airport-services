/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;

/**
 *
 * @author it21221
 */
public class Monitor {
    
    private double inches ;
    
    private double price;
    
    public Monitor(double inches, double price){
        this.inches=inches;
        this.price=price;
    }

    public double getInches() {
        return inches;
    }

    public void setInches(double inches) {
        this.inches = inches;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    @Override
    public String toString(){
       return "Monitor inches: "+inches; 
    }
}
