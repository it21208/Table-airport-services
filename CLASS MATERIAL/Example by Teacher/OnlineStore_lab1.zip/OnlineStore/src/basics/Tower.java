/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;

/**
 *
 * @author it21221
 */
public class Tower {
    
    private String cpu ;
    
    private int storage;
     
    private double price ;
    
    public Tower(String cpu, int storage, double price){
        this.cpu=cpu;
        this.price=price;
        this.storage=storage;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String Cpu) {
        this.cpu = Cpu;
    }

    public int getStorage() {
        return storage;
    }

    public void setStorage(int storage) {
        this.storage = storage;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    @Override
    public String toString(){
        return "cpu:"+cpu+" storage: "+storage;
    }
}
