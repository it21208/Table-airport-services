
package basics;

import java.util.ArrayList;



public class Order {
    
    ArrayList<OrderItem> list ;
    
    public double getTotalOrderCost(){
        return -1;
    }
    
    public void printOrderDetails(){
        
    }
    
    public void addItem(Product p, int quant){
        
    }
    
    
}
