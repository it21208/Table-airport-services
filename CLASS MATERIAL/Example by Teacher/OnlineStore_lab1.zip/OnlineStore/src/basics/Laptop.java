/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;

/**
 *
 * @author it21221
 */
public class Laptop extends Product {
    
    private int hdSize;
    
    private int[] mon_resolution;
    
    public double getTax(){
        return Product.vat;
    }
    
    public double getPriceWithTax(){
        return getTax()+price;
    }
    
    public Laptop(String model,double price,int hdSize,int width,int length){
        super(model,price); //prepei na kalei ton apopanw prwta 
        this.hdSize=hdSize;
        this.mon_resolution = new int[2]  ;
        this.mon_resolution[0]= width;
        this.mon_resolution[1]= length;
    }
    
    public String toString(){
        super.toString();
        return "Hard drive size: "+hdSize+" "+"monitore solution: "+mon_resolution[0]+"x"+mon_resolution[1] ;
    }
}
