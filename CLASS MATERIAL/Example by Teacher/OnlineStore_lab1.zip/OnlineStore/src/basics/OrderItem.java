
package basics;


public class OrderItem {
    
    private Product prod;
    
    private int quantity;
    
    

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    
}
