/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;


/**
 *
 * @author it21221
 */
public abstract class Product {
    
    @Override
    public String toString(){
       return "model:"+ this.model; 
    }
    
    public static double vat = 0.23;
    
    protected  double price;
    
    protected String model;
    
    public abstract double getTax();
    
    public abstract double getPriceWithTax();
    
    public Product (String model, double price){
        this.model=model;
        this.price=price;
    }
    
}
