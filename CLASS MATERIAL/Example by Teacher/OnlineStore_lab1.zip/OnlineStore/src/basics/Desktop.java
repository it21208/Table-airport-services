/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basics;

/**
 *
 * @author it21221
 */
public class Desktop extends Product {
    
    private Monitor mon ;
    
    private Tower tow ;
    
    public Desktop (String model, Monitor mon, Tower tow){
        super(model,mon.getPrice()+tow.getPrice());
        this.mon=mon;
        this.tow=tow;
        
    }
    
    
     public double getTax(){
        return Product.vat;
    }
    
    public double getPriceWithTax(){
        return getTax()+price;
    }
    
    @Override
    public String toString(){
       return mon+""+tow; 
    }
}
